READ ME FOR CITY BUILD!
Game not need installing.
Starting:
Unzip the city build 1.1.5.zip file.
DO NOT MOVE FILES IN THE UNZIPPED FOLDER.
When unzipped go to unzipped folder and
open city build.exe.
Game starting.


WHEN THE GAME DISPLAYS ERROR OPENTOEDIT FAILED OR MEMORY ACCESS VIOLATION OR OPENTOWRITE THEN RELAUNCH THE GAME AND SELECT MENU AND SELECT BUG REPORT (YOU NEED EMAIL!).


Thank you for installing the city build.
ENJOY :D