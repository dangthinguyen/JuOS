First please do not edit any files in this folder!!!

The app doesn't need installation.
Created by: Juuso Laine
Current version:0.01
